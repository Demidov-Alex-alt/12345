import math

class RightTriangle:
    def __init__(self, side1, side2):
        self.side1 = side1
        self.side2 = side2

    def increase_size(self, percent):
        self.side1 += self.side1 * percent / 100
        self.side2 += self.side2 * percent / 100

    def decrease_size(self, percent):
        self.side1 -= self.side1 * percent / 100
        self.side2 -= self.side2 * percent / 100

    def radius_of_circumscribed_circle(self):
        hypotenuse = math.sqrt(self.side1**2 + self.side2**2)
        radius = hypotenuse / 2
        return radius

    def perimeter(self):
        hypotenuse = math.sqrt(self.side1**2 + self.side2**2)
        perimeter = self.side1 + self.side2 + hypotenuse
        return perimeter

    def angles(self):
        angle1 = math.degrees(math.atan(self.side2 / self.side1))
        angle2 = math.degrees(math.atan(self.side1 / self.side2))
        angle3 = 90
        return angle1, angle2, angle3

# Пример
triangle = RightTriangle(3, 4)
triangle.increase_size(10)
print("Side 1:", triangle.side1) # 3.3
print("Side 2:", triangle.side2) # 4.4

radius = triangle.radius_of_circumscribed_circle()
perimeter = triangle.perimeter()
angle1, angle2, angle3 = triangle.angles()

print("Radius of the circumscribed circle:", radius)
print("Perimeter:", perimeter)
print("Angles:", angle1, angle2, angle3)