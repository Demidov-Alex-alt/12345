class Vector3D:
    def __init__(self, x=0, y=0, z=0):  # constructor
        self.x = x
        self.y = y
        self.z = z

    def __add__(self, other):  # vector addition
        return Vector3D(self.x + other.x, self.y + other.y, self.z + other.z)

    def __sub__(self, other):  # vector subtraction
        return Vector3D(self.x - other.x, self.y - other.y, self.z - other.z)

    def __mul__(self, other):  # scalar multiplication and dot product
        if isinstance(other, Vector3D):  # dot product
            return self.x * other.x + self.y * other.y + self.z * other.z
        else:  # scalar multiplication
            return Vector3D(self.x * other, self.y * other, self.z * other)

    def __matmul__(self, other):  # cross product
        return Vector3D(self.y * other.z - self.z * other.y,
                        self.z * other.x - self.x * other.z,
                        self.x * other.y - self.y * other.x)

    def read(self):
        self.x = float(input('Enter x: '))
        self.y = float(input('Enter y: '))
        self.z = float(input('Enter z: '))

    def display(self):
        print('({:.2f}, {:.2f}, {:.2f})'.format(self.x, self.y, self.z))


# Your example usages:
v1 = Vector3D(4, 1, 2)
v1.display()
v2 = Vector3D()
v2.read()
v3 = Vector3D(1, 2, 3)
v4 = v1 + v2
v4.display()
a = v4 * v3
print(a)
v4 = v1 * 10
v4.display()
v4 = v1 @ v3
v4.display()
