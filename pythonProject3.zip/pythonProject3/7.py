class Bus:
    def __init__(self, max_speed, capacity):
        self.speed = 0
        self.capacity = capacity
        self.max_speed = max_speed
        self.passengers = []
        self.hasEmptySeats = True
        self.seats = {}

    def add_passenger(self, *names):
        for name in names:
            if len(self.passengers) < self.capacity:
                self.passengers.append(name)
                self.seats[name] = len(self.passengers)
                print(f"{name} сел в автобус на место {self.seats[name]}")
            else:
                print(f"Нет свободных мест. {name} не может сесть в автобус.")

    def remove_passenger(self, *names):
        for name in names:
            if name in self.passengers:
                self.passengers.remove(name)
                seat = self.seats.pop(name)
                print(f"{name} вышел из автобуса с места {seat}")
            else:
                print(f"{name} не найден в автобусе.")

    def increase_speed(self, value):
        if self.speed + value <= self.max_speed:
            self.speed += value
            print(f"Скорость автобуса увеличена на {value} км/ч. Текущая скорость: {self.speed} км/ч.")
        else:
            print(f"Максимально допустимая скорость автобуса: {self.max_speed} км/ч.")

    def decrease_speed(self, value):
        if self.speed - value >= 0:
            self.speed -= value
            print(f"Скорость автобуса уменьшена на {value} км/ч. Текущая скорость: {self.speed} км/ч.")
        else:
            print("Скорость автобуса уже равна нулю.")

    def __contains__(self, name):
        return name in self.passengers

    def __iadd__(self, name):
        self.add_passenger(name)
        return self

    def __isub__(self, name):
        self.remove_passenger(name)
        return self


# Пример использования:

bus = Bus(max_speed=80, capacity=30)
print(bus.hasEmptySeats)

bus.add_passenger("Иван", "Мария", "Алексей", "Елена")

print(bus.hasEmptySeats)
print("Иван" in bus)
print("Петр" in bus)

bus.remove_passenger("Мария", "Петр")

bus.increase_speed(20)
bus.decrease_speed(10)
bus.decrease_speed(15)

bus += "Николай"
bus -= "Алексей"
